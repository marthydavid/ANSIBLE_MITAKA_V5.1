genpasswd() {
        tr -dc "A-Za-z0-9_" < /dev/urandom | head -c ${1:-8} | xargs
}

fname="./group_vars/all"

# Delete old file if exsists
if [ -f "${fname}" ]; then
    echo -n "Delete exsisting file: "
    rm -f $fname
    touch $fname
    echo "Done"
fi

# Generate passwords for deployment
for line in $(cat pw.template)
do
    if [ "${line}" == "RABBITMQ_erlang_cookie" ]; then
        er=`python ./pwgen.py`
        echo "${line}: '${er}'" >> $fname
        unset er
        # BUFULRARFLBEOLYHWGRE
    else
        value=`genpasswd 18`
        echo "${line}: '${value}'" >> $fname
        unset value
    fi
done

# Remove empty lines
sed -i '/^\s*$/d' "${fname}" 

# Check number of the generated lines (validate)
if [ $(wc -l < "${fname}") -eq $(wc -l < ./pw.template) ]; then
    echo "File generation was successful"
else
    echo "File generation was failed!"
fi
