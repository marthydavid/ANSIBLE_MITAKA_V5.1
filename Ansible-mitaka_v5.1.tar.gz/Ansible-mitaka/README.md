# Openstack deploy with Ansible
Requirements:

Ansible node:
    OS: Ubuntu Linux 14.04.5 server 64 bit
    Deployment: Ansible 2.2.0  
    OpenStack version: Mitaka
    Generated ssh-key for user (no root from security point of view)

VM node:
    OS: Ubuntu Linux 14.04.5 server 64 bit
    Installed package: SSH server (openssh-server)
    Existing public key for the user (install it from Ansible node as user with "ssh-copy-id <username>@<VM IP>")

# Openstack Network plan:

Management network: 172.17.0.0/24 (vboxnetX)
Tunnel network:     172.17.1.0/24 (vboxnetY)
Storage network:    172.17.2.0/24 (vboxnetZ)
External network:   Your network  (bridged adapter)

# Node minimal configurations
Controller node:
    hostname: cc1,
    CPU: 1 vcpu,
    Memory: 3072MB,
    Disk: 16 GB HDD,
    Network adapters:
        NIC1 (host-only adapter, management network, IP 172.17.0.1),
        NIC2 (NAT, dhcp)

Network node:
    hostname: net1,
    CPU: 1 vcpu,
    Memory: 1024MB,
    Disk: 8 GB HDD,
    Network adapters:
        NIC1 (host-only adapter, management network, IP 172.17.0.2),
        NIC2 (NAT, dhcp),
        NIC3 (Bridged apater, External network, IP address depend on your network)
        NIC4 (host-only adapter, tunnel network network, IP 172.17.1.2),

Compute node:
    hostname: cn1,
    CPU: 2 vcpu,
    Memory: 1536MB,
    Disk: 20 GB HDD,
    Network adapters:
        NIC1 (host-only adapter, management network, IP 172.17.0.3),
        NIC2 (NAT, dhcp),
        NIC3 (host-only adapter, tunnel network network, IP 172.17.1.3),
        
Storage node:
    hostname: str1,
    CPU: 1 vcpu,
    Memory: 512MB,
    Disk1: 8 GB HDD for OS
    Disk2: 16GB for LVM
    Network adapters:
        NIC1 (host-only adapter, management network, IP 172.17.0.4),
        NIC2 (NAT, dhcp),

Install Ubuntu 14.04.5 server on all node. (important steps)
    Install language: English
    Mirror: United Kingdom
    Keyboard: Hungarian
    Primary network interface: eth1
    Partitions: Guided partitioning
    Create user for login t the node (preferred name same as the Ansible deployment node)
    Package: SSH Server
    Install Grub to /dev/sda (MBR)

Login to the nodes via console:
    Configure all network interfaces (be careful on the network node with the external netwrork adater configuration! See below the example)
    Reboot the node (network node will be start much slower, but it is noprmal, because the br-ex adater preconfigured, but not exist now)
    
Generate and copy ssh keys on Ansible deployment node:
    Create ssk key:              ssh-keygen -b 2048 -t rsa
    Copy public key to all node: ssh-copy-id username@<ip address of the node>
    Login to the nodes via SSH:  ssh username@<ip address of the node>

If it is done please create a snapshot about every nodes. Preferred name of the snapshot is "Original"
The preparation steps is done.

Help for the network card configurations

# Network configuration examples
##Internal adatper configuration:
auto eth0
iface eth0 inet static
        address 172.17.0.2
        netmask 255.255.255.0

##External adapter network configuration:
Just an example:
    auto eth2
    iface eth2 inet manual
    up ifconfig $IFACE 0.0.0.0 up
    up ip link set $IFACE promisc on
    down ip link set $IFACE promisc off
    down ifconfig $IFACE down
    
    # For giving access to network node via. the external network
    auto br-ex
    iface br-ex inet static
    address 192.168.0.99
    netmask 255.255.255.0


# Genarate passwords for deployment

## Two files prepared for this:
    pw.template - it contains the variable names (do not change it!)
    pwgen.sh - it will generate a new variables file with the passwords in group_vars directory. The file name is "all"
    pwgen.py - it can generate Erlang cookie compatible password (this script is used by pwgen.sh)

Run script pwgen.sh (if you cannot run run this command chmod u+x pwgen.sh)

## Anible-plugins

### inidata plugin

It need for the more dimensions array for ini_file option. It can generate ini_data format from array.
If you want to use it, please follow the instructions below.

1. Check your ansible.cfg file in /etc/ansible and find the lookup plugin folder setting.
2. Create lookup_plugins folder if not exsist (i.e. Ubuntu: mkdir -p /usr/share/ansible_plugins/lookup_plugins )
3. Clone this repo to your machine and copy ansible-plugins/inidata.py to lookup plugins folder
   i.e. cp ansible-plugins/inidata.py /usr/share/ansible_plugins/lookup_plugins/
4. You can use it same as ini file format. Please check the example:

example ini file:

```
    [DEFAULT]
    # Show more verbose log output (sets INFO log level output)
    #verbose = False
 
    # Show debugging output in logs (sets DEBUG log level output)
    #debug = False
 
    # Maximum image size (in bytes) that may be uploaded through the
    # Glance API server. Defaults to 1 TB.
    # WARNING: this value should only be increased after careful consideration
    # and must be set to a value under 8 EB (9223372036854775808).
    #image_size_cap = 1099511627776
     
    # Address to bind the API server
    bind_host = 0.0.0.0
     
    # Port the bind the API server to
    bind_port = 9292
```

example vars file:

```
    glance_api:
      DEFAULT:
        verbose: True
        debug: False
        bind_host: 0.0.0.0
        bind_port: 9292
```

example task:

```
    - name: Configure glance-api.conf
      ini_file:
        dest: /etc/glance/glance-api.conf
        owner: glance 
        group: glance
        mode: 0640
        backup: yes
        section: "{{ item.0 }}"
        option: "{{ item.1 }}"
        value: "{{ item.2 }}"
      with_inidata: glance_api
```

Please be careful! The ini_file component doesn't remove the default config, but remove the commented out lines! So if you need remove some existing config you need remove it manualy from the configuration file.
If something doesn't exist in the ini file the ini_file add the missing entries.

## Dependencies (packages, you can install it from repo)

- python-netaddr
- python-pymongo

## How to use these roles with different environment?

Every enviroments have a separated host and groupvars files. The host files schema is same you need change this parameter [env_name:children].

```
    Change parent name of the host group:
    Old.: [mitaka.**test**:children]
    New:  [mitaka.**dev2**:children]
    
    You can change the numbers of the nodes in every group if need.
```

Group vars:
The group vars names are inherited from parent name of the host group. If you need a new environment, you need take a copy about an existing groupvars file with the inherited name. Please check the example below.

```
    i.e. [mitaka.test:children] -> mitaka
```

Usage:
- If the username is different please change the mitaka file in the playbook folder:
Here is an example:
```
    [controller-nodes]
    cc1 ansible_ssh_host=172.17.0.1 ansible_ssh_user=username
```


- Build cloud on test environment

```
    ansible-playbook -i mitaka.test mitaka.yml
    - i   name of the environment (host file)
    Name of the playbook: mitaka.yml
```
    
- Run specific task/role on the affected nodes.

```
    ansible-playbook -i mitaka mitaka.yml --tags common-headless
    --tags  run only tagged tasks. Every role name are tags as well. i.e. common tag = common role
```

```
- Run roles on specific nodes
    ansible-playbook -i mitaka mitaka.yml --limit cc1
    --limit run only roles on selected hosts
```