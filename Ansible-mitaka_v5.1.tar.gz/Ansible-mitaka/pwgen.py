import string
import random

print(''.join(random.choice(string.ascii_uppercase) for i in range(20)))
